﻿using Paw_inc.Models;

namespace Paw_inc.Interfaces.Animals
{
    public interface ITheAnimals
    {
        string Name { get; }
        int Age { get; }
        string CleaningStatus { get; set; }
        TheCenters FromCenter { get; }
    }
}