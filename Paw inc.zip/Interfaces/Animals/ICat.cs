﻿namespace Paw_inc.Interfaces.Animals
{
    public interface ICat:ITheAnimals
    {
        int IntelligenceCoefficient { get; }
    }
}