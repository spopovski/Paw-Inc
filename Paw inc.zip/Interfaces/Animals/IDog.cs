﻿namespace Paw_inc.Interfaces.Animals
{
    public interface IDog:ITheAnimals
    {
        int AmauntOfCommands { get; }
    }
}