﻿namespace Paw_inc.Interfaces.Centers
{
    public interface ITheCenters
    {
        string Name { get;}
    }
}