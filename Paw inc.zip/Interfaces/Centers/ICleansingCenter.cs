﻿using System.Collections.Generic;

namespace Paw_inc.Interfaces.Centers
{
    public interface ICleansingCenter:ITheCenters
    {
        List<TheAnimals> CleanAnimals { get; set; }
    }
}