﻿using System.Collections.Generic;

namespace Paw_inc.Interfaces.Centers
{
    public interface IAdoptionCenters:ITheCenters
    {
        List<TheAnimals> AdoptingAnimals { get; set; }
    }
}