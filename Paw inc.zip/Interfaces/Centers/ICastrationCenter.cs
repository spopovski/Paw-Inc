﻿using System.Collections.Generic;

namespace Paw_inc.Interfaces.Centers
{
    public interface ICastrationCenter:ITheCenters
    {
        List<TheAnimals> CastratingAnimals { get; set; }
    }
}