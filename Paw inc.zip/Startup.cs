﻿using System;
using System.Collections.Generic;
using System.Linq;
using Paw_inc.Models;
using Paw_inc.Models.Animals;

namespace Paw_inc
{
    class Startup
    {
        static void Main(string[] args)
        {
            Dictionary<TheCenters, List<TheAnimals>> PawInc = new Dictionary<TheCenters, List<TheAnimals>>();
            List<TheAnimals> adoptedAnimals = new List<TheAnimals>();
            List<TheAnimals> cleansingAnimals = new List<TheAnimals>();
            int cleansingCenterCount = 0;
            int adoptinCenterCount = 0;
            int castrationCenterCount = 0;
            string input = Console.ReadLine();
            while (input != "Paw Paw Pawah")
            {
                string[] info = input.Split(new char[] { ' ', '|' }, StringSplitOptions.RemoveEmptyEntries);
                string command = info[0];
                string name = String.Empty;
                int age = 0;
                int commandOrIntelligence = 0;
                string addoptionCenterName = String.Empty;
                string cleansingCenterName = String.Empty;
                if (command.EndsWith("Center"))
                {
                    name = info[1];
                }
                else if (command.StartsWith("Register"))
                {
                    name = info[1];
                    age = int.Parse(info[2]);
                    commandOrIntelligence = int.Parse(info[3]);
                    addoptionCenterName = info[4];
                }
                else if (command.StartsWith("Send"))
                {
                    addoptionCenterName = info[1];
                    cleansingCenterName = info[2];
                }
                else if (command == "Cleanse" || command == "Castrate")
                {
                    cleansingCenterName = info[1];
                }
                else if (command == "Adopt")
                {
                    addoptionCenterName = info[1];
                }
                switch (command)
                {
                    case "RegisterCleansingCenter":
                        TheCenters newCleanse = new CleansingCenter(name);
                        PawInc.Add(newCleanse, new List<TheAnimals>());
                        cleansingCenterCount++;
                        break;
                    case "RegisterAdoptionCenter":
                        TheCenters newAdopt = new AdoptionCenters(name);
                        PawInc.Add(newAdopt, new List<TheAnimals>());
                        adoptinCenterCount++;
                        break;
                    case "RegisterCastrationCenter":
                        TheCenters newCastration = new CastrationCenter(name);
                        PawInc.Add(newCastration, new List<TheAnimals>());
                        castrationCenterCount++;
                        break;
                    case "RegisterDog":
                        TheCenters findAdoptionCenterDog = PawInc.Keys.First(n => n.Name == addoptionCenterName);
                        TheAnimals newDog = new Dog(name, age, findAdoptionCenterDog, commandOrIntelligence);
                        PawInc[findAdoptionCenterDog].Add(newDog);
                        break;
                    case "RegisterCat":
                        TheCenters findAdoptionCenterCat = PawInc.Keys.First(n => n.Name == addoptionCenterName);
                        TheAnimals newCat = new Cat(name, age, findAdoptionCenterCat, commandOrIntelligence);
                        PawInc[findAdoptionCenterCat].Add(newCat);
                        break;
                    case "SendForCleansing":
                        TheCenters fromAdoptionCenter = PawInc.First(n => n.Key.Name == addoptionCenterName).Key;
                        var sending = PawInc.First(n => n.Key.Name == cleansingCenterName).Key;
                        var search = PawInc.First(n => n.Key.Name == addoptionCenterName);
                        var toCleansingCenter = search.Value.FindAll(n => n.CleaningStatus == "UNCLEANSED");
                        foreach (var palenca in toCleansingCenter)
                        {
                            PawInc[sending].Add(palenca);
                            PawInc[fromAdoptionCenter].Remove(palenca);
                        }
                        break;
                    case "SendForCastration":
                        TheCenters fromAdoptionC = PawInc.First(n => n.Key.Name == addoptionCenterName).Key;
                        var sendIt = PawInc.First(n => n.Key.Name == cleansingCenterName).Key;
                        var searchIt = PawInc.First(n => n.Key.Name == addoptionCenterName);
                        var toCastrationCenter = searchIt.Value.ToList();
                        foreach (var palenca in toCastrationCenter)
                        {
                            PawInc[sendIt].Add(palenca);
                            PawInc[fromAdoptionC].Remove(palenca);
                        }
                        break;
                    case "Cleanse":
                        var cleanThem = PawInc.First(n => n.Key.Name == cleansingCenterName);
                        foreach (var forCleaning in cleanThem.Value)
                        {
                            forCleaning.CleaningStatus = "CLEANSED";
                        }
                        TheCenters fromCleansingCenter = PawInc.First(n => n.Key.Name == cleansingCenterName).Key;
                        var finding = PawInc.First(n => n.Key.Name == cleansingCenterName);
                        var toAdoptinCenter = finding.Value.FindAll(n => n.CleaningStatus == "CLEANSED");
                        foreach (var palenca in toAdoptinCenter)
                        {
                            cleansingAnimals.Add(palenca);
                            PawInc[palenca.FromCenter].Add(palenca);
                            PawInc[fromCleansingCenter].Remove(palenca);
                        }
                        break;
                    case "Castrate":
                        var castrateThem = PawInc.First(n => n.Key.Name == cleansingCenterName);
                        var findIt = PawInc.First(n => n.Key.Name == cleansingCenterName);
                        var toAdoptinC = findIt.Value.ToList();
                        foreach (var palenca in toAdoptinC)
                        {
                            PawInc[palenca.FromCenter].Add(palenca);
                        }
                        break;
                    case "Adopt":
                        var puppies = PawInc.First(n => n.Key.Name == addoptionCenterName).Value;
                        var toAdopting = puppies.FindAll(n => n.CleaningStatus == "CLEANSED").ToList();
                        TheCenters RemoveRegistration = PawInc.First(n => n.Key.Name == addoptionCenterName).Key;
                        foreach (var adopt in toAdopting)
                        {
                            if (adopt.CleaningStatus == "CLEANSED")
                            {
                                adoptedAnimals.Add(adopt);
                                PawInc[RemoveRegistration].Remove(adopt);
                            }
                        }
                        break;
                    case "CastrationStatistics":
                        var findCenter = PawInc.Where(n => n.Key.GetType().ToString() == "CastrationCenter").ToList();
                        Console.WriteLine("Paw Inc. Regular Castration Statistics");
                        Console.WriteLine($"Castration Centers: {castrationCenterCount}");
                        foreach (var castrated in findCenter)
                        {
                            var castratedAnimals = castrated.Value.ToList();
                            if (castratedAnimals.Count == 0)
                            {
                                Console.WriteLine("Castrated Animals: None");
                            }
                            else
                            {
                                Console.WriteLine($"Castrated Animals: {string.Join(", ", castratedAnimals.Select(n => n.Name).OrderBy(n => n))}");

                            }
                        }
                        break;
                }

                input = Console.ReadLine();
            }

            int animalsAwaitingAdoption = PawInc.Sum(n => n.Value.Count(m => m.CleaningStatus == "CLEANSED"));
            int animalsAwaitingCleansing = PawInc.Where(n => n.Key.GetType().ToString() == "CleansingCenter").Sum(n => n.Value.Count(m => m.CleaningStatus == "UNCLEANSED"));
            var findAdoptionCenterCount = PawInc.Keys.Count(n => n.GetType().ToString() == "AdoptionCenters");
            var findCleansingCenterCount = PawInc.Keys.Count(n => n.GetType().ToString() == "CleansingCenters");
            Console.WriteLine("Paw Incorporative Regular Statistics");
            Console.WriteLine($"Adoption Centers: {adoptinCenterCount}");
            Console.WriteLine($"Cleansing Centers: {cleansingCenterCount}");
            if (adoptedAnimals.Count == 0)
            {
                Console.WriteLine("Adopted Animals: None");
            }
            else
            {
                Console.WriteLine(
                    $"Adopted Animals: {string.Join(", ", adoptedAnimals.Select(n => n.Name).OrderBy(n => n))}");
            }
            if (cleansingAnimals.Count == 0)
            {
                Console.WriteLine("Cleansed Animals: None");
            }
            else
            {
                Console.WriteLine(
                    $"Cleansed Animals: {string.Join(", ", cleansingAnimals.Select(n => n.Name).OrderBy(n => n))}");
            }
            Console.WriteLine($"Animals Awaiting Adoption: {animalsAwaitingAdoption}");
            Console.WriteLine($"Animals Awaiting Cleansing: {animalsAwaitingCleansing}");

        }
    }
}
