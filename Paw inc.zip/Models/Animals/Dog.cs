﻿using Paw_inc.Interfaces.Animals;

namespace Paw_inc.Models.Animals
{
    public class Dog:TheAnimals,IDog
    {
        public Dog(string name, int age, TheCenters fromCenter, int amauntOfCommands) : base(name, age, fromCenter)
        {
            AmauntOfCommands = amauntOfCommands;
        }

        public int AmauntOfCommands { get; }
    }
}