﻿
using Paw_inc.Interfaces.Animals;
using Paw_inc.Models;

public abstract class TheAnimals : ITheAnimals
{
    protected TheAnimals(string name, int age, TheCenters fromCenter)
    {
        Name = name;
        Age = age;
        CleaningStatus = "UNCLEANSED";
        FromCenter = fromCenter;
    }

    public string Name { get; }
    public int Age { get; }
    public string CleaningStatus { get; set; }
    public TheCenters FromCenter { get; }
}