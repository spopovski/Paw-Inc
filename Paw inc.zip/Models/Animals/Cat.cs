﻿using Paw_inc.Interfaces.Animals;
using Paw_inc.Models;

public class Cat : TheAnimals,ICat
{
    public Cat(string name, int age, TheCenters fromCenter, int intelligenceCoefficient) : base(name, age, fromCenter)
    {
        IntelligenceCoefficient = intelligenceCoefficient;
    }

    public int IntelligenceCoefficient { get; }
}
