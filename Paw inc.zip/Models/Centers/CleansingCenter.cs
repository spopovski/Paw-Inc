﻿using System.Collections.Generic;
using Paw_inc.Interfaces.Centers;
using Paw_inc.Models;

public class CleansingCenter:TheCenters,ICleansingCenter
    {
        public CleansingCenter(string name) : base(name)
        {
            CleanAnimals = new List<TheAnimals>();
        }

        public List<TheAnimals> CleanAnimals { get; set; }
    }