﻿using System.Collections.Generic;
using Paw_inc.Interfaces.Centers;
using Paw_inc.Models;

public class CastrationCenter:TheCenters,ICastrationCenter
    {
        public CastrationCenter(string name) : base(name)
        {
        }

        public List<TheAnimals> CastratingAnimals { get; set; }
    }
