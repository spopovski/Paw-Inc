﻿using System.Collections.Generic;
using Paw_inc.Interfaces.Centers;

namespace Paw_inc.Models
{
    public abstract class TheCenters:ITheCenters
    {
        public string Name { get; }

        protected TheCenters(string name)
        {
            Name = name;
        }
    }
}