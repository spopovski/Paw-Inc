﻿using System.Collections.Generic;
using Paw_inc.Interfaces.Centers;
using Paw_inc.Models;

public class AdoptionCenters : TheCenters, IAdoptionCenters
{
    public AdoptionCenters(string name) : base(name)
    {
        AdoptingAnimals = new List<TheAnimals>();
    }

    public List<TheAnimals> AdoptingAnimals { get; set; }
}